#pragma once
class Define
{
public:
	typedef void (*CallBackFunc)();



};

