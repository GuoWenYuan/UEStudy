#pragma once
#include "AEvent.h"

class TestEvent:AEvent
{
public:
	 void Run();

};