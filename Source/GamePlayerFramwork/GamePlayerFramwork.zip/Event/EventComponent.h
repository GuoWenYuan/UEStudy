#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "AEvent.h"

class EventComponent
{
private:
	TMap<FString, AEvent> eventPool;

public:
	void AddEvent(FString eventName, AEvent *eventActor);
	AEvent GetEvent(FString eventName);
	void RemoveEvent(FString eventName);
	void RunEvent(FString eventName);
	template<typename T>
	void RunEvent(FString eventName, T t);
	template<typename T,typename T1>
	void RunEvent(FString eventName, T t,T1 t1);
};

inline void EventComponent::RunEvent(FString eventName)
{
	AEvent m_Event = GetEvent(eventName);
	if (m_Event != NULL)
	{
		m_Event.Run();
	}
}

template<typename T>
inline void EventComponent::RunEvent(FString eventName, T t)
{
	AEvent m_Event = GetEvent(eventName);
	if (m_Event != NULL)
	{
		m_Event.Run(t);
	}
	
}

template<typename T, typename T1>
inline void EventComponent::RunEvent(FString eventName, T t, T1 t1)
{
	AEvent m_Event = GetEvent(eventName);
	if (m_Event != NULL)
	{
		m_Event.Run(t,t1);
	}
}

inline void EventComponent::AddEvent(FString eventName, AEvent *eventActor)
{
	if (!eventPool.Contains(eventName))
	{
		eventPool.Add(eventName);
	}
	eventPool[eventName] = eventActor;

}

inline AEvent EventComponent::GetEvent(FString eventName)
{
	return eventPool[eventName];	
}

inline void EventComponent::RemoveEvent(FString eventName)
{
	if (eventPool.Contains(eventName))
	{
		eventPool.Remove(eventName);
	}
}
