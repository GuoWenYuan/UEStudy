#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"


class AEvent
{
public:
	int refCount;
	void Run();
	template<typename T>
	void Run(T a);
	template<typename T, typename T1>
	void Run(T a, T1 a1);
};

/*
template <typename T>
class AEvent:public AEvent
{
public:
	override void Run(T t);

};


template <typename T,T1>
class AEvent:public AEvent
{
public:
	override void Run(T t,T1 t1);

};

*/
