#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GameMain.generated.h"


 class Event 
{
private:
	TMap<FString,event>

};